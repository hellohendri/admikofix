<?php
/** Admiko version file **/
/**
 * @author     Thank you for using Admiko.com
 * @copyright  2020-2022
 * @link       https://Admiko.com
 * @Help       We are always looking to improve our code. If you know better and more creative way don't hesitate to contact us. Thank you.
 */
/**
 * This file will be overwritten on update. Don't add your code here!
 */
return [
    'project_key'             => 'Caf171bd21a4e941f8b8038da3fc079d6bc120fd526ef3e83c',
    'version'             => 0.917
];
