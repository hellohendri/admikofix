<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route("admin.login")); ?>" class="needs-validation" novalidate>
        <?php echo csrf_field(); ?>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger invalid-feedback d-block"><?php echo e(session()->get('error')); ?></div>
        <?php endif; ?>
        <label for="email" class="mb-1"><?php echo e(trans('admiko.email')); ?>:</label>
        <input type="text" class="form-control mb-1" required="true" id="email" name="email" placeholder="<?php echo e(trans('admiko.username')); ?>" value="<?php echo e(old('email')); ?>" autofocus>
        <?php if($errors->has('email')): ?>
            <div class="invalid-feedback d-block"><?php echo e($errors->first('email')); ?></div>
        <?php endif; ?>
        <div class="invalid-feedback"><?php echo e(trans('admiko.required_username')); ?></div>
        <label for="password" class="mb-1"><?php echo e(trans('admiko.password')); ?>:</label>
        <input type="password" class="form-control mb-1" id="password" required="true" name="password" placeholder="<?php echo e(trans('admiko.password')); ?>">
        <?php if($errors->has('password')): ?>
            <div class="invalid-feedback d-block"><?php echo e($errors->first('password')); ?></div>
        <?php endif; ?>
        <div class="invalid-feedback">
            <?php echo e(trans('admiko.required_password')); ?>

        </div>
        <small><a href="<?php echo e(route("admin.password.request")); ?>"><?php echo e(trans('admiko.forgot_pass')); ?></a></small>
        <div class="form-check my-2">
            <input class="form-check-input" type="checkbox" value="1" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label class="form-check-label" for="remember">
                <?php echo e(trans('admiko.remember_me')); ?>

            </label>
        </div>
        <div class="row">
            <div>
                <button type="submit" class="btn btn-primary w-100"><?php echo e(trans('admiko.login_button')); ?></button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\admikofix\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>