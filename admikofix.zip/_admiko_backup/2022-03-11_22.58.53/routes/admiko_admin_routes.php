<?php
/** Admiko routes. This file will be overwritten on page import. Don't add your code here! **/
/**
 * @author     Thank you for using Admiko.com
 * @copyright  2020-2022
 * @link       https://Admiko.com
 * @Help       We are always looking to improve our code. If you know better and more creative way don't hesitate to contact us. Thank you.
 */
namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Route;
